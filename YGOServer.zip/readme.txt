﻿房间规则
N|M|T    0|1|2|o|t   0|1|o|t    0-9             T|F|1|0                 T|F|1|0               T|F|1|0             0-9      0-9      0-9       #name$password
mode模式,rule规则,banlist禁卡,outtime超时分钟,EnablePriority效果优先权,NoCheckDeck不检查卡组,NoShuffleDeck不洗牌,lp[*4000],hand手牌,draw抽卡数,#,房间名,$,密码
TOO3TTT851#asd$123
NAO3FFF#xxxx$123
NTT3#xxxx$123
NTO#xxxx$123
MA#xxxx$123
N#xxxx$123
xxxxx$123
xxxx
空则是随机

更新历史：
0.5
登录失败提示
中文提示
空连接处理
0.4.8
正式版本
AI支持比赛模式
换side，掉线处理
0.4.7
无需管理员身份运行
0.4.6
修复无法连接bug
0.4.5
登录公告
0.4.4
添加AI到房间
玩家/ai
服务端addai 随机到一个房间
